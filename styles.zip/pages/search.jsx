import HomeLayout from "@/components/Layout/HomeLayout"

 

const Search = () => {
    return (
        <HomeLayout>
            
        </HomeLayout>
    )
}
export default Search